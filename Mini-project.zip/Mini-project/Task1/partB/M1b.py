#!/usr/bin/python3
import sys
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize 

for line in sys.stdin:
        line = json.loads(line)
        print(line['author']+'|'+ line['subreddit'],1,sep='\t')


            

