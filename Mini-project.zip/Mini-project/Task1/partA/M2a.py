#!/usr/bin/python3
import sys

for line in sys.stdin:
    key,value = line.strip().split()
    array = string.split("|")
    subreddit = array[0]
    topic = array[1]
    print(subreddit,topic,value,sep='\t')

    
