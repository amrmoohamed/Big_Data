#!/usr/bin/python3
import sys

for line in sys.stdin:
        line = json.loads(line)
        
        print(line['controversiality'],line['ups'],line['downs'],sep='\t')
