#!/usr/bin/python3
import sys

for line in sys.stdin:
    key,value = line.strip().split()
    array = string.split("|")
    user = array[0]
    subreddit = array[1]
    print(user,subreddit,value,sep='\t')
    
