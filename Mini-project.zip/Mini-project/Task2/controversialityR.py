#!/usr/bin/python3
import sys

word = None 
count = 0
summation = 0
average = 0

for line in sys.stdin:
    key,value1,value2 = line.strip().split()
    
    if word is None:
        word = key
    elif word != key:
        average = summation / count
        print(word, average, sep='\t')
        word = key
        count = 0
        summation = 0
    
    summation = summation + value1 + value2  
    count += 1
    
average = summation / count 
print(word, average, sep='\t')
    
