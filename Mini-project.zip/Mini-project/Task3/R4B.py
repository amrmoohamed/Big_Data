#!/usr/bin/python3
import sys
from collections import Counter


dicts = []

for line in sys.stdin:
    dummy,key,value = line.strip().split()
    dicts[key] = value
print("Top 10 topics with most upvotes are ".dict(Counter(dicts).most_common(10)))
