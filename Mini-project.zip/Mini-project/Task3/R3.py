#!/usr/bin/python3
import sys

word = None
count = 0

for line in sys.stdin:
    topic,upvotes = line.strip().split()
    
    if word is None:
        word = topic
        
    elif word != topic.:
        print(word, count, sep='\t')
        word = topic
        count = 0
    count += int(upvotes)

print(word, count, sep='\t')

