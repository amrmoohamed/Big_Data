#!/usr/bin/python3
import sys
from collections import Counter


word = None
dicts = []

for line in sys.stdin:
    user,subreddit,value = line.strip().split()
    
    if word is None:
        word = user
    elif word != user:
        print("most 5 subreddit for {} user are".format(user),dict(Counter(dicts).most_common(5)))
        dict = []
        word = user
    
    dicts[subreddit] = value
print("most 5 subreddit for {} user are".format(user),dict(Counter(dicts).most_common(5)))

