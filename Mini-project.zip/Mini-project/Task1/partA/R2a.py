#!/usr/bin/python3
import sys
from collections import Counter


word = None
dicts = []

for line in sys.stdin:
    subreddit,topic,value = line.strip().split()
    
    if word is None:
        word = subreddit
    elif word != subreddit:
        print("most 10 topics in {} subreddit are".format(subreddit),dict(Counter(dicts).most_common(10)))
        dict = []
        word = subreddit
    
    dicts[topic] = value
print("most 10 topics in {} subreddit are".format(subreddit),dict(Counter(dicts).most_common(10)))
    
    
