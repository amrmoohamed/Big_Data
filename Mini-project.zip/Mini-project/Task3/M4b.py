#!/usr/bin/python3
import sys

for line in sys.stdin:
    key,value = line.strip().split()
    print(1,key,value,sep='\t')

    
